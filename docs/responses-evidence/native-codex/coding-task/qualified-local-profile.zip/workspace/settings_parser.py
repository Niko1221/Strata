def parse_settings(text):
    if not isinstance(text, str):
        raise TypeError("settings text must be a str")

    result = {}
    for number, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "=" not in stripped:
            raise ValueError("missing '=' on line %d: %r" % (number, line))
        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            raise ValueError("empty key on line %d: %r" % (number, line))
        if key in result:
            raise ValueError("duplicate key %r on line %d" % (key, number))
        result[key] = value
    return result
