"""Companion real-native HTTP fault probes; not a Codex task or mocked model."""
import argparse
import json
import os
from pathlib import Path
import socket
import time
import urllib.error
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('--base-url', required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--codex')
parser.add_argument('--timeout')
args = parser.parse_args()
args.out.mkdir(parents=True)
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
base = args.base_url.removesuffix('/v1')
key = os.environ['STRATA_API_KEY']
headers = {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}
basic = {'model': 'qwen3.8-flash-next', 'store': False, 'input': 'Say ready.', 'reasoning': {'effort': 'none'}, 'temperature': 0}
record = {'result': 'running', 'scripted_model_output': False, 'cases': []}
peers = []

def save():
    (args.out / 'result.json').write_text(json.dumps(record, indent=2), encoding='utf-8')

def get(path):
    with opener.open(urllib.request.Request(base + path, headers=headers), timeout=15) as response:
        return json.load(response)

def send(body, auth=True):
    raw = body if isinstance(body, bytes) else json.dumps(body).encode()
    req = urllib.request.Request(base + '/v1/responses', data=raw, headers=headers if auth else {'Content-Type': 'application/json'})
    try:
        response = opener.open(req, timeout=180)
        peers.append(response)
        return response
    except urllib.error.HTTPError as exc:
        return exc

def idle():
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        metrics = get('/metrics')
        if metrics['live']['state'] == 'idle' and metrics['live']['queued'] == 0:
            return metrics
        time.sleep(.3)
    raise AssertionError('service did not drain back to idle')

def close_peer(response):
    # urllib close alone may leave a buffered socket alive; explicitly send FIN.
    sock = response.fp.raw._sock
    sock.shutdown(socket.SHUT_RDWR)
    response.close()

def until(response, event_type):
    events = []
    while line := response.readline():
        if line.startswith(b'data:'):
            event = json.loads(line[5:])
            events.append(event)
            if event['type'] == event_type:
                return events
    raise AssertionError('stream ended before ' + event_type)

try:
    record['health_before'] = get('/health')
    record['metrics_before'] = get('/metrics')
    tests = [('unauthenticated', basic, False, 401),
             ('duplicate-json', b'{"model":"qwen3.8-flash-next","store":false,"store":false,"input":"x","stream":true}', True, 400),
             ('non-finite-json', b'{"model":"qwen3.8-flash-next","store":false,"input":"x","temperature":NaN}', True, 400),
             ('background', {**basic, 'background': True}, True, 400),
             ('retained-store', {**basic, 'store': True}, True, 400),
             ('previous-response', {**basic, 'previous_response_id': 'resp_missing'}, True, 400),
             ('unknown-model', {**basic, 'model': 'missing'}, True, 404),
             ('bad-tools-array', {**basic, 'tools': {}}, True, 400),
             ('strict-tool', {**basic, 'tools': [{'type': 'function', 'name': 'test', 'strict': True}]}, True, 400),
             ('custom-lark', {**basic, 'tools': [{'type': 'custom', 'name': 'test', 'format': {'type': 'grammar', 'syntax': 'lark', 'definition': 'start: "x"'}}]}, True, 400),
             ('json-object', {**basic, 'text': {'format': {'type': 'json_object'}}}, True, 400),
             ('orphan-tool-result', {**basic, 'input': [{'type': 'function_call_output', 'call_id': 'call_missing', 'output': 'x'}]}, True, 400),
             ('foreign-encrypted-state', {**basic, 'input': [{'type': 'reasoning', 'id': 'rs_foreign', 'summary': [], 'encrypted_content': 'opaque-foreign-state'}]}, True, 400),
             ('context-overflow', {**basic, 'max_output_tokens': 50000}, True, 400)]
    for name, body, auth, expected in tests:
        if isinstance(body, dict):
            body = {**body, 'stream': True}
        with send(body, auth) as response:
            item = {'name': name, 'status': response.status, 'content_type': response.headers.get('Content-Type'),
                    'request': body.decode() if isinstance(body, bytes) else body, 'response': json.load(response)}
        record['cases'].append(item)
        save()
        assert item['status'] == expected and item['content_type'].startswith('application/json'), item
        print(name + ': rejected before SSE headers', flush=True)
    with send({**basic, 'input': 'List all numbers from 1 to 1000.', 'max_output_tokens': 1}) as response:
        body = json.load(response)
        assert response.status == 200 and body['status'] == 'incomplete' and body['incomplete_details']['reason'] == 'max_output_tokens', body
        record['cases'].append({'name': 'output-budget', 'response': body})
    save()
    # Close during prefill, then verify drain and ordinary generation afterward.
    response = send({**basic, 'input': ('alpha beta gamma delta\n' * 1800) + 'Summarize briefly.', 'max_output_tokens': 1000, 'stream': True})
    assert response.status == 200
    events = until(response, 'response.in_progress')
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        live = get('/metrics')['live']
        if live['state'] == 'reading' and (live.get('prompt_read') or 0) > 0:
            break
        time.sleep(.1)
    assert live['state'] == 'reading' and 0 < live['prompt_read'] < live['prompt_total'], live
    close_peer(response)
    after = idle()
    record['cases'].append({'name': 'disconnect-prefill', 'events_before_close': events, 'observed_phase': live, 'after': after['live']})
    save()
    # Hold one real decode active while another request queues; disconnect both.
    first = send({**basic, 'input': 'List the integers from 1 to 10000, one per line. Do not stop early.', 'max_output_tokens': 6000, 'stream': True})
    first_events = until(first, 'response.output_text.delta')
    second = send({**basic, 'stream': True, 'max_output_tokens': 32})
    second_events = until(second, 'response.created')
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        live = get('/metrics')['live']
        if live['queued'] >= 1:
            break
        time.sleep(.1)
    assert live['state'] == 'generating' and live['queued'] >= 1, live
    close_peer(second)
    close_peer(first)
    after = idle()
    record['cases'].append({'name': 'disconnect-queued-and-decode', 'observed': live, 'first_events': first_events,
                            'second_events': second_events, 'after': after['live']})
    save()
    with send({**basic, 'input': 'Reply with exactly READY.', 'max_output_tokens': 64}) as response:
        body = json.load(response)
        assert response.status == 200 and body['status'] == 'completed', body
        text = ''.join(p['text'] for i in body['output'] if i['type'] == 'message' for p in i['content'])
        assert text.strip() == 'READY', text
        record['cases'].append({'name': 'generation-after-drain', 'response': body})
    record['metrics_after'] = idle()
    record['result'] = 'pass'
finally:
    for peer in peers:
        if not peer.closed:
            try:
                close_peer(peer)
            except (OSError, AttributeError, ValueError):
                peer.close()
    save()
print(json.dumps({'result': record['result'], 'cases': len(record['cases'])}), flush=True)
