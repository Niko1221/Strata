def parse_settings(text):
    if not isinstance(text, str):
        raise TypeError("parse_settings() requires a str; got %r" % type(text).__name__)

    settings = {}
    for number, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "=" not in line:
            raise ValueError("missing = on line %d: %r" % (number, line))
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            raise ValueError("empty key on line %d: %r" % (number, line))
        if key in settings:
            raise ValueError("duplicate key %r on line %d" % (key, number))
        settings[key] = value.strip()
    return settings
