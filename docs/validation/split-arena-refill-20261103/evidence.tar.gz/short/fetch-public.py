"""Fetch only explicitly public experiment records, never private profiles or state."""
import pathlib,subprocess,io,tarfile,json
p=pathlib.Path(__file__).resolve().parent
remote=r'''import pathlib,sys,tarfile
p=pathlib.Path.home()/"strata-deploy/comparisons/20261103-q6-batch-refill"
allowed={"results.json","production-before.json","production-after.json","controller.log","watchdog.log","retry.log","refill-experiment.temperatures.jsonl","refill-experiment.perf.stat","refill-experiment.observer-errors.log","engine-public.log","config-redacted.json","container.log"}
with tarfile.open(fileobj=sys.stdout.buffer,mode="w|gz") as tar:
 for f in sorted(p.rglob("*")):
  if f.is_file() and f.name in allowed and "artifact" not in f.relative_to(p).parts:tar.add(f,arcname=str(f.relative_to(p)))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','zhangjiayi@<private-server>','python3 -'],input=remote.encode(),capture_output=True,check=True)
raw=p/'raw';raw.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(r.stdout),mode='r:gz') as t:t.extractall(raw,filter='data')
print(json.dumps(dict(files=len(list(raw.rglob('*'))),compressed_bytes=len(r.stdout))))
