import pathlib,json,shutil,concurrent.futures,urllib.request,hashlib,tarfile
root=pathlib.Path('/data/benchmark/benchmarks/results/20261103-q6-batch-refill');r=json.loads((root/'cuda-redist-manifest.json').read_text())
p=pathlib.Path('/tmp/strata-refill-cuda13');p.mkdir(exist_ok=True)

if not (p/'bin/nvcc').exists():shutil.copytree('/usr/local/cuda-13.1',p,dirs_exist_ok=True,symlinks=True)
# libcublas headers and matching library already installed by NVIDIA Python package.
cu=pathlib.Path('/data/benchmark/.local/lib/python3.14/site-packages/nvidia/cu13')
for f in (cu/'include').glob('*blas*.h'):shutil.copy2(f,p/'include'/f.name)
for name in ['libcublas.so.13','libcublasLt.so.13']:
 t=p/'lib64'/name
 if not t.exists():t.symlink_to(cu/'lib'/name)
 link=p/'lib64'/name.replace('.so.13','.so')
 if not link.exists():link.symlink_to(name)
def get(k):
 x=r[k]['linux-x86_64'];data=urllib.request.urlopen('https://developer.download.nvidia.com/compute/cuda/redist/'+x['relative_path'],timeout=90).read();assert hashlib.sha256(data).hexdigest()==x['sha256']
 f=pathlib.Path('/tmp')/pathlib.Path(x['relative_path']).name;f.write_bytes(data);return k,f
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for k,f in ex.map(get,['cuda_crt','cuda_cudart','cuda_cccl','libnvvm']):
  with tarfile.open(f) as t:
   for m in t:
    parts=pathlib.PurePosixPath(m.name).parts[1:]
    if not parts or '..' in parts or not m.isfile():continue
    # redist components put include/lib at root, toolkit uses target directory.
    if parts[0] in ('include','lib'):parts=('targets','x86_64-linux',parts[0],*parts[1:])
    target=p.joinpath(*parts);target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() or target.is_symlink():target.unlink()
    target.write_bytes(t.extractfile(m).read());target.chmod(m.mode)
  print('READY',k,flush=True)
print('toolkit',p,flush=True)
