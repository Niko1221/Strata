#!/usr/bin/env python3
"""Upload public experiment artifacts into the existing NAS Share; verify every SHA256."""
import hashlib,json,os,pathlib,shutil,subprocess
ROOT=pathlib.Path(__file__).resolve().parent;STAGE=ROOT/'delivery';STAGE.mkdir(exist_ok=True)
for name in ['report.md','summary.json','production-verification.json','raw/results.json','artifact.tar.gz']:assert (ROOT/name).is_file(),name
for name in ['run-experiment.py','watchdog.py','thermal-helper.py','fixtures.json','split-arena-async.patch','source-origin.json','strata-99866a47.tar.gz','build-command.sh','prepare-toolchain.py','cuda-redist-manifest.json','check-default-preprocess.py','default-preprocess-check.json','method.md','reproduce.md','fetch-public.py','builder-image.txt','builder-apt.log','review.md','build.log','configure-debian.log','builder.log','rebuild.log','compatibility-help.log','llama-3cf03257.tar.gz','report.md','generate-report.py','summary.json','analyze.py','production-verification.json','verify-production.py','archive.py']:
 p=ROOT/name
 if p.is_file():shutil.copy2(p,STAGE/name)
if (ROOT/'raw').is_dir():shutil.copytree(ROOT/'raw',STAGE/'raw',dirs_exist_ok=True)
if (ROOT/'artifact.tar.gz').is_file():shutil.copy2(ROOT/'artifact.tar.gz',STAGE/'artifact.tar.gz')
lines=[]
for p in sorted(STAGE.rglob('*')):
 if p.is_file() and p.name not in ['SHA256SUMS','archive-verification.json']:
  with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
  lines.append(h+'  '+str(p.relative_to(STAGE)))
(STAGE/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
c=dict(l.split('=',1) for l in pathlib.Path('/data/benchmark/.nas-credentials').read_text().splitlines() if '=' in l)
env=os.environ.copy();env['SSHPASS']=c['password'].strip();host=c['username'].strip()+'@<private-server>';dest='<private-NAS-archive>/strata/20261103-q6-batch-refill'
ssh=['sshpass','-e','ssh',host]
subprocess.run(ssh+['mkdir -p '+dest],env=env,check=True,capture_output=True)
subprocess.run(['sshpass','-e','scp','-qr',str(STAGE)+'/.',host+':'+dest+'/'],env=env,check=True,capture_output=True)
code='''import hashlib,json,pathlib
r=pathlib.Path("<private-NAS-archive>/strata/20261103-q6-batch-refill");n=0;size=0
for line in (r/"SHA256SUMS").read_text().splitlines():
 h,name=line.split("  ",1);p=r/name
 with p.open("rb") as f:a=hashlib.file_digest(f,"sha256").hexdigest()
 assert a==h,name
 n+=1;size+=p.stat().st_size
v=dict(directory=str(r),verified_files=n,verified_bytes=size,all_sha256_match=True)
(r/"archive-verification.json").write_text(json.dumps(v,indent=2));print(json.dumps(v))
'''
v=subprocess.run(ssh+['python3 -'],input=code,env=env,text=True,capture_output=True,check=True);receipt=json.loads(v.stdout);(ROOT/'archive-verification.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,ensure_ascii=False))
