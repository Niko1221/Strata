import pathlib,subprocess,json
p=pathlib.Path(__file__).resolve().parent
remote=r'''import pathlib,subprocess,json,urllib.request,hashlib,time
r=pathlib.Path.home()/"strata-deploy";cfgbytes=(r/"config/run.json").read_bytes();c=json.loads(cfgbytes)
def sh(a):return subprocess.check_output(a,text=True)
d=json.loads(sh(["docker","inspect","strata-q4"]))[0]
assert d["State"]["Running"] and not d["State"]["Paused"]
assert d["State"]["Health"]["Status"]=="healthy",d["State"]["Health"]["Status"]
op=urllib.request.build_opener(urllib.request.ProxyHandler({}));headers={"Authorization":"Bearer "+c["api_key"]}
metrics=json.load(op.open(urllib.request.Request("http://127.0.0.1:8080/metrics",headers=headers),timeout=10))
names=sh(["docker","ps","--format","{{.Names}}"] ).splitlines();assert not any(x in names for x in ["strata-refill-experiment","strata-quant-registers","strata-quant-perf"])
image=d["Image"];sha=sh(["docker","exec","strata-q4","sha256sum",c["exe"]]).split()[0];configsha=hashlib.sha256(cfgbytes).hexdigest()
assert image=="sha256:4c4abcf786268af3dba47570ea5bffdd325bc91a62d957331d5852b11d49d0da"
assert sha=="e4406b474c292c8b52621c803f523ae18dc42c905deda60d5f055740c7ef8925"
assert configsha=="f8f602cf86d198dc413ff4f2a1f94f5e7103337fceec3e495bef89ef22cb4c82"
freeze=pathlib.Path('/sys/fs/cgroup/system.slice/docker-'+d['Id']+'.scope/cgroup.freeze').read_text().strip();assert freeze=='0'
gpus=sh(["nvidia-smi","--query-gpu=index,name,power.limit,temperature.gpu,memory.used","--format=csv,noheader,nounits"]).splitlines();assert len(gpus)==2
for gpu in gpus:assert float(gpu.split(',')[2])==280
hc=d['HostConfig'];assert hc['NanoCpus']==0 and hc['CpuQuota'] in [0,-1]
print(json.dumps(dict(verified_unix=time.time(),healthy=True,original_image_id=image,original_engine_sha256=sha,original_config_sha256=configsha,config_unchanged=True,engine_unchanged=True,engine=metrics['engine'],live=metrics['live'],restart_policy=hc['RestartPolicy'],cpuset=hc['CpusetCpus'],nano_cpus=hc['NanoCpus'],cpu_quota=hc['CpuQuota'],cgroup_freeze=freeze,gpus=gpus,experimental_containers_absent=True)))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','zhangjiayi@<private-server>','python3 -'],input=remote,text=True,capture_output=True,check=True)
d=json.loads(r.stdout);(p/'production-verification.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(d,ensure_ascii=False))
