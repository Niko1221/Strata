import json,pathlib,datetime,statistics
p=pathlib.Path(__file__).resolve().parent;s=json.loads((p/'summary.json').read_text());r=json.loads((p/'raw/results.json').read_text());v=json.loads((p/'production-verification.json').read_text());a,b=s['groups']['A'],s['groups']['B']
def f(x):return f'{x:.2f}'
def signed(x):return f'{x:+.2f}%'
clear=b['dual_joint_min']>a['dual_joint_max'] and s['dual_percent']>3
conclusion=('双请求短程测试显示正向收益，但样本较少，仍不足以承诺所有负载均有同等提升。' if clear else '本轮不足以证明稳定的双请求 decode 收益；不将实验补丁部署到生产。')
lines=['# 双 GPU 跨窗口专家搬运实验', '',conclusion,'',f"双请求共同解码区间吞吐：A {f(a['dual_joint_mean'])} → B {f(b['dual_joint_mean'])} token/s（{signed(s['dual_percent'])}）。单请求 native decode：{f(a['single_native_mean'])} → {f(b['single_native_mean'])} token/s（{signed(s['single_percent'])}）。原生产容器已恢复，未永久部署补丁。",'', '## 实际结果','', '| 指标 | A：原阻塞路径 | B：跨窗口搬运 |', '|---|---:|---:|',f"| 双请求共同解码区间均值，token/s | {f(a['dual_joint_mean'])} | {f(b['dual_joint_mean'])} |",f"| 双请求最小–最大，token/s | {f(a['dual_joint_min'])}–{f(a['dual_joint_max'])} | {f(b['dual_joint_min'])}–{f(b['dual_joint_max'])} |",f"| 双请求测量次数 | {a['dual_n']} | {b['dual_n']} |",f"| 文章请求 native decode 均值，token/s | {f(a['dual_native_by_prompt']['1817'])} | {f(b['dual_native_by_prompt']['1817'])} |",f"| SVG 请求 native decode 均值，token/s | {f(a['dual_native_by_prompt']['1836'])} | {f(b['dual_native_by_prompt']['1836'])} |",f"| 单请求 native decode，token/s | {', '.join(map(f,a['single_native']))} | {', '.join(map(f,b['single_native']))} |",'', '共同解码区间使用 /metrics 中两槽同时处于 decoding 状态的最长连续区间，去掉两端各一次采样；并非把两个具有不同起止时间的 native 平均速率直接相加。native 数值单独列出。文章/SVG 提示分别为1817/1836 token，每个正式请求输出512 token，温度0、关闭思考。正式双请求复用相同提示的缓存；这不是长上下文或 uncached prefill 测试。','', '| 轮次 | 场景 | 共同区间合计 token/s | native decode token/s | 最高温度 °C |','|---|---|---:|---|---:|']
for x in s['rows']:
 if x['boot']=='safety-B' or x['case']=='warmup':continue
 lines.append(f"| {x['boot']} | {x['case']} | {f(x['joint']['total_tokens_per_second']) if 'joint' in x else '—'} | {', '.join(str(z['decode_tok_s']) for z in x['native'])} | {x['temperature_max_c']} |")
lines+=['','## 每窗口开销','', '以下为正式双请求按窗口数加权的主机侧计时。CUDA wait 是主机等 GPU 到达 CPU 专家处理点的时间，不能作为某个 CUDA 算子的纯设备执行时间。','', '| 指标，ms/窗口 | A | B |','|---|---:|---:|']
for field,label in [('total_ms','窗口总耗时'),('run_ms','run'),('commit_ms','commit'),('emit_ms','emit'),('adapt_ms','自适应搬运等待')]:lines.append(f"| {label} | {f(a['dual_batch_weighted_ms'][field])} | {f(b['dual_batch_weighted_ms'][field])} |")
for k in ['0','1']:
 for field,label in [('wait_ms','GPU-reach wait'),('pool_ms','CPU expert pool')]:lines.append(f"| CUDA{k} {label} | {f(a['dual_stage_weighted_ms'][k][field])} | {f(b['dual_stage_weighted_ms'][k][field])} |")
lines+=['','| 路由/MTP 指标 | A | B |','|---|---:|---:|']
for field in ['vram','pcie','cpu']:lines.append(f"| {field} 路由占比 | {f(a['dual_routing_weighted_percent'][field])}% | {f(b['dual_routing_weighted_percent'][field])}% |")
lines.append(f"| MTP 接受率，正式双请求累计 | {f(a['dual_mtp']['percent'])}% | {f(b['dual_mtp']['percent'])}% |")
lines.append('')
lines.append(f"自适应搬运等待平均减少 {f(a['dual_batch_weighted_ms']['adapt_ms']-b['dual_batch_weighted_ms']['adapt_ms'])} ms/窗口，同时 run 改变 {f(b['dual_batch_weighted_ms']['run_ms']-a['dual_batch_weighted_ms']['run_ms'])} ms/窗口；窗口总耗时净减少 {f(a['dual_batch_weighted_ms']['total_ms']-b['dual_batch_weighted_ms']['total_ms'])} ms。这是主机计时的差值，不是对内存带宽争用等底层原因的直接证明。")
for flag,name in [(False,'A'),(True,'B')]:
 samples=[x['native'][0] for x in s['rows'] if x['enabled']==flag and x['case']=='single']
 lines.append(f"单请求{name}的MTP接受率："+'、'.join(f"{100*x['drafts_accepted']/x['drafts_offered']:.1f}%（{x['drafts_accepted']}/{x['drafts_offered']}）" for x in samples)+'。')
lines.append('单请求只有A两次、B一次，输出和MTP接受率存在变化，且两边使用了实验调度覆盖值；不能把单请求差值直接当作对原生产默认调度的确定收益。')
lines+=['','异步搬运会让待换出的专家先走 CPU，再在全部所属 GPU 复制完成后发布新专家。等待减少不等于总耗时必然同比减少；CPU 专家工作量、路由和 MTP 接受率都可能改变。route_resident=0.1 会按驻留状态影响选择，因此输出不保证逐 token 相同；本轮端到端差值不能全部归因于纯传输重叠。','', '## 安全检查与边界','',f"独立 safety-B 在256窗口报告0次驻留表不一致、0条不一致表项、0次 CPU 专家缺失激活发布。性能轮关闭了会同步 GPU 流的 STRATA_ADAPT_CHECKRES。所有接受的请求最高温度为{s['max_temperature_c']}°C，IMC thermal PMU 事件为0，计数器运行比例均大于99.9%。这只覆盖固定短程负载的一致性与错误检查，不是数学等价或模型语义质量认证。",'', 'A/B 使用同一个干净0.1.55源码构建的 ELF，只切换实验开关。双方均显式设置 NOWAIT=0、LAG=1 和 --adapt-async 1；原生产 SM86 默认是 NOWAIT=1、LAG=2，保持未改。因此本轮比较的是匹配的实验调度，不能直接当作对所有原生产行为、尤其单请求的升级承诺。顺序为 safety-B、A1、B1、A2，各正式启动先双请求预热256，再双请求512两次、单请求512一次。B双请求仅2个样本，A有4个，无统计显著性结论。','', '加载阶段使用2 CPU的总配额避免重载热冲击；发请求前解除为 CpuQuota=-1、NanoCpus=0，并额外核实 cgroup cpu.max=max。16个工作线程和原CPU亲和性不变。实验容器仅绑定127.0.0.1:8081，外部独立40分钟 watchdog 用于失败恢复。CUDA专用，未测试HIP/SYCL。','', '前四轮预检全部排除：1）未启用实验路径；2）启动温度守卫中止；3）发现SM86内部默认NOWAIT/LAG阻止门控；4）Docker --cpus 0未解除原配额，发请求前检查中止。第3轮含原生产重载最高65°C，第4轮最高63°C；这些不属于正式性能请求。公开原始日志及失败记录一并保留。','', '## 生产恢复与归档','',f"原镜像：`{v['original_image_id']}`。",'',f"原引擎SHA256：`{v['original_engine_sha256']}`。",'',f"原配置SHA256：`{v['original_config_sha256']}`。",'', '最终检查：8080健康、两张RTX3080都在且功耗上限280W、原restart policy保留、无CPU总配额、cgroup未冻结、实验和温度观察容器已退出。详见 production-verification.json。','', 'NAS：`<private-NAS-archive>/strata/20261103-q6-batch-refill/`。含源码归档、补丁、可执行文件、构建过程、原始公开测量、分析脚本、静态独立审查和复现说明；不含私有API密钥/生产配置副本。SHA256SUMS及archive-verification.json记录归档校验。']
temps=[json.loads(x) for x in (p/'raw/refill-experiment.temperatures.jsonl').read_text().splitlines() if x.strip()]
whole_max=max(t for row in temps for pair in row['temperatures_c'] for t in pair)
lines+=['',f'本轮包含加载、停机和原服务恢复在内的全程最高记录温度：{whole_max}°C；请与上文正式请求期间的最高温度区分。']
(p/'report.md').write_text('\n'.join(lines)+'\n')
print(conclusion)
