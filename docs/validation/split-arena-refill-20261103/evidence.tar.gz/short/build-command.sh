#!/bin/sh
# Run inside a Debian12 builder with g++, make, CMake4 and a complete CUDA13.1 toolkit.
# Source archive and ggml oracle archive are identified in source-origin.json/method.md.
set -eu
: "${SPIKE_ROOT:?set SPIKE_ROOT to this project directory}"
: "${CUDA_ROOT:?set CUDA_ROOT to a CUDA13.1 toolkit}"
: "${GGML_ROOT:?set GGML_ROOT to llama.cpp3cf03257 with ggml}"
cmake -S "$SPIKE_ROOT/source" -B "$SPIKE_ROOT/build-debian" -G 'Unix Makefiles' \
 -DCMAKE_BUILD_TYPE=Release -DSTRATA_ENABLE_CUDA=ON -DSTRATA_BUILD_TESTS=OFF \
 -DSTRATA_PORTABLE=ON -DSTRATA_NATIVE_EXPERTS=ON -DSTRATA_Q6K_EXPERTS=ON \
 -DSTRATA_MMQ_KQUANTS=ON -DSTRATA_MMQ_TAB=OFF \
 -DCMAKE_CUDA_COMPILER="$CUDA_ROOT/bin/nvcc" -DCUDAToolkit_ROOT="$CUDA_ROOT" \
 -DCMAKE_CUDA_ARCHITECTURES=86-real -DSTRATA_GGML_DIR="$GGML_ROOT" \
 -DCMAKE_CXX_FLAGS=-DSTRATA_SPLIT_ARENA_ASYNC_EXPERIMENT=1 -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
cmake --build "$SPIKE_ROOT/build-debian" --target strata strata_kq -j6
