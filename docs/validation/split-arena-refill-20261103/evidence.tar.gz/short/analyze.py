#!/usr/bin/env python3
import json,pathlib,re,statistics
R=pathlib.Path(__file__).resolve().parent;raw=R/'raw';d=json.loads((raw/'results.json').read_text())
assert d.get('completed') and not d.get('error'),d.get('error')
assert d['production_restored'] and d['config_unchanged']
assert d['original_engine_sha256']==d['restored_engine_sha256']
rows=[];boots=[]
for b in d['boots']:
 log=(raw/b['label']/'engine-public.log').read_text();stats=[]
 for line in log.splitlines():
  m=re.search(r'strata batch: (\d+) windows, avg ([\d.]+) rows, ([\d.]+) ms/window = run ([\d.]+) .*? \+ commit ([\d.]+) \+ emit ([\d.]+) \+ adapt wait ([\d.]+);',line)
  if m:
   n,avg,total,run,commit,emit,adapt=map(float,m.groups());stage={int(k):{'wait_ms':float(w),'pool_ms':float(p)} for k,w,p in re.findall(r'CUDA(\d+) wait ([\d.]+) \+ pool ([\d.]+)',line)}
   stats.append(dict(windows=int(n),avg_rows=avg,total_ms=total,run_ms=run,commit_ms=commit,emit_ms=emit,adapt_ms=adapt,stages=stage,line=line))
 mtp=[dict(accepted=int(a),offered=int(o),percent=float(p)) for a,o,p in re.findall(r'MTP proposals accepted (\d+) of (\d+) \(([\d.]+)%\)',log)]
 dual_cases=[c for c in b['cases'] if len(c['tasks'])==2];assert len(stats)==len(dual_cases)==len(mtp),(b['label'],len(stats),len(dual_cases),len(mtp))
 mapped={}
 for c,st,mt in zip(dual_cases,stats,mtp):
  st['case']=c['label'];st['mtp']=mt;route=re.search(r'routed entries per window: VRAM [\d.]+ \(([\d.]+)%\), PCIe [\d.]+ \(([\d.]+)%\), CPU [\d.]+ \(([\d.]+)%\)',st['line']);st['routing_percent']=dict(zip(['vram','pcie','cpu'],map(float,route.groups()))) if route else {};mapped[c['label']]=st
 checks=re.findall(r'res check: (\d+) windows, (\d+) with mismatches \((\d+) entries\), (\d+) layer-windows',log)
 if b['checkres']:assert checks and all(all(int(x)==0 for x in c[1:]) for c in checks)
 for c in b['cases']:
  assert c['temperature_max_c']<63 and not c['thermal_pmu']['nonzero_thermal_events'] and c['thermal_pmu']['running_percent_min']>99.9
  for req in c['requests']:assert req['finish']=='length' and req['usage']['completion_tokens']==c['cap']
  row=dict(boot=b['label'],enabled=b['enabled'],case=c['label'],temperature_max_c=c['temperature_max_c'],native=[{k:v for k,v in z.items() if k not in ['id','time']} for z in c['native']],sse_rates=[z['decode_sse_tok_s'] for z in c['requests']])
  if 'joint_decode' in c:row['joint']=c['joint_decode']
  if c['label'] in mapped:row['batch_stats']=mapped[c['label']]
  rows.append(row)
 boots.append(dict(label=b['label'],engine=b['engine'],batch_stats=stats,residency_checks=checks,mtp=[dict(accepted=int(a),offered=int(o),percent=float(p)) for a,o,p in re.findall(r'MTP proposals accepted (\d+) of (\d+) \(([\d.]+)%\)',log)]))
groups={}
for enabled in [False,True]:
 selected=[x for x in rows if x['enabled']==enabled and x['case'].startswith('dual-') and x['boot']!='safety-B'];singles=[x for x in rows if x['enabled']==enabled and x['case']=='single']
 rates=[x['joint']['total_tokens_per_second'] for x in selected]
 assert len(rates)==(2 if enabled else 4)
 groups['B' if enabled else 'A']=dict(dual_n=len(rates),dual_joint_mean=statistics.mean(rates),dual_joint_min=min(rates),dual_joint_max=max(rates),dual_joint_stdev=statistics.stdev(rates),dual_rates=rates,single_native_mean=statistics.mean(x['native'][0]['decode_tok_s'] for x in singles),single_native=[x['native'][0]['decode_tok_s'] for x in singles])
for key,enabled in [('A',False),('B',True)]:
 selected=[x for x in rows if x['enabled']==enabled and x['case'].startswith('dual-') and x['boot']!='safety-B'];stats=[x['batch_stats'] for x in selected];n=sum(x['windows'] for x in stats)
 groups[key]['dual_batch_weighted_ms']={field:sum(x[field]*x['windows'] for x in stats)/n for field in ['total_ms','run_ms','commit_ms','emit_ms','adapt_ms']}
 groups[key]['dual_stage_weighted_ms']={str(k):{field:sum(x['stages'][k][field]*x['windows'] for x in stats)/n for field in ['wait_ms','pool_ms']} for k in [0,1]}
 groups[key]['dual_routing_weighted_percent']={field:sum(x['routing_percent'][field]*x['windows'] for x in stats)/n for field in ['vram','pcie','cpu']}
 accepted=sum(x['mtp']['accepted'] for x in stats);offered=sum(x['mtp']['offered'] for x in stats);groups[key]['dual_mtp']=dict(accepted=accepted,offered=offered,percent=100*accepted/offered)
 groups[key]['dual_native_by_prompt']={str(prompt):statistics.mean(r['decode_tok_s'] for x in selected for r in x['native'] if r['prompt_tokens']==prompt) for prompt in [1817,1836]}
a,b=groups['A'],groups['B'];summary=dict(groups=groups,dual_percent=100*(b['dual_joint_mean']/a['dual_joint_mean']-1),single_percent=100*(b['single_native_mean']/a['single_native_mean']-1),max_temperature_c=max(x['temperature_max_c'] for x in rows),rows=rows,boots=boots,restored_original_engine=True)
(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['rows','boots']},ensure_ascii=False,indent=2))
