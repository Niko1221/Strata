import hashlib,json,pathlib,shlex,subprocess
r=pathlib.Path('/data/benchmark/benchmarks/results/20261103-q6-batch-refill')
a=next(x for x in json.loads((r/'build-debian/compile_commands.json').read_text()) if x['file'].endswith('/src/program/generate.cpp'))
cmd=shlex.split(a['command']);src=cmd[-1];args=[];i=0
while i<len(cmd):
 x=cmd[i]
 if x in ['-o','-c']:
  if x=='-o':i+=2
  else:i+=1
  continue
 if 'STRATA_SPLIT_ARENA_ASYNC_EXPERIMENT' in x or x==src:i+=1;continue
 args.append(x);i+=1
hashes=[]
for name,p in [('patched',src),('original',str(r/'generate.original.cpp'))]:
 out=r/('preprocess-'+name+'.i')
 with out.open('wb') as f:subprocess.run(args+['-E','-P',p],cwd=a['directory'],stdout=f,check=True)
 hashes.append(hashlib.sha256(out.read_bytes()).hexdigest());out.unlink()
assert hashes[0]==hashes[1],hashes
(r/'default-preprocess-check.json').write_text(json.dumps({'macro_disabled_preprocessed_equal':True,'sha256':hashes[0],'compiler_command':args},indent=2)+'\n')
print('Macro-disabled preprocessed translation units match:',hashes[0])
