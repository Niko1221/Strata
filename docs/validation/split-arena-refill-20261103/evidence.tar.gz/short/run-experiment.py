#!/usr/bin/env python3
"""Isolated CUDA-only async-refill spike. Original production is always restarted."""
import concurrent.futures as cf
import copy,hashlib,importlib.util,json,os,pathlib,re,subprocess,threading,time,urllib.request
ROOT=pathlib.Path.home()/'strata-deploy'; OUT=ROOT/'comparisons/20261103-q6-batch-refill'
IMAGE='strata:control-0.1.55-engine-0.1.55-cuda13'; NAME='strata-refill-experiment'
spec=importlib.util.spec_from_file_location('thermal',OUT/'thermal-helper.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q);q.OUT=OUT;q.IMAGE=IMAGE
original=(ROOT/'config/run.json').read_bytes();cfg=json.loads(original);headers={'Authorization':'Bearer '+cfg['api_key'],'Content-Type':'application/json'}
op=urllib.request.build_opener(urllib.request.ProxyHandler({}));fixtures=json.loads((OUT/'fixtures.json').read_text());stop=threading.Event()
result={'started_unix':time.time(),'boots':[],'config_sha256':hashlib.sha256(original).hexdigest()};thermal=None;down=False;watch=None

def sh(args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw).stdout

def save():q.save(OUT/'results.json',result)

def api(path,port=8081):return json.load(op.open(urllib.request.Request(f'http://127.0.0.1:{port}'+path,headers=headers),timeout=8))

def ready(port,seconds=660):
 deadline=time.monotonic()+seconds
 while time.monotonic()<deadline:
  try:
   m=api('/metrics',port)
   if m.get('engine',{}).get('expert_slots',0)>0 and m['live']['running']==0:return m
  except Exception:pass
  if thermal and port==8081:assert thermal.maximum()<63,'Thermal guard during startup'
  time.sleep(2)
 raise RuntimeError('Startup timeout')

def cool(target=55):
 deadline=time.monotonic()+600
 while thermal.maximum()>target:
  assert time.monotonic()<deadline,'Cooling timeout';time.sleep(2)

def generate(task,cap,barrier,model,origin):
 barrier.wait();events=[];usage={};finish=None;started=time.monotonic()
 body=dict(model=model,messages=[dict(role='user',content=fixtures[task])],max_tokens=cap,temperature=0,stream=True,stream_options={'include_usage':True},chat_template_kwargs={'enable_thinking':False})
 req=urllib.request.Request('http://127.0.0.1:8081/v1/chat/completions',data=json.dumps(body,ensure_ascii=False).encode(),headers=headers)
 with op.open(req,timeout=90) as r:
  for line in r:
   assert not stop.is_set() and thermal.maximum()<63,'Test guard'
   if not line.startswith(b'data: '):continue
   raw=line[6:].strip()
   if raw==b'[DONE]':break
   item=json.loads(raw);assert not item.get('error'),item;usage=item.get('usage') or usage
   for c in item.get('choices',[]):
    content=c.get('delta',{}).get('content') or c.get('delta',{}).get('reasoning_content')
    if content:events.append(dict(seconds=time.monotonic()-origin,text=content))
    finish=c.get('finish_reason') or finish
 assert usage.get('completion_tokens')==cap and finish=='length',(usage,finish)
 return dict(task=task,events=events,usage=usage,finish=finish,ttft_s=events[0]['seconds']-(started-origin),decode_sse_tok_s=(cap-1)/(events[-1]['seconds']-events[0]['seconds']))

def measure(boot,label,tasks,cap=512):
 cool();assert api('/metrics')['live']['running']==0
 ids={r['id'] for r in api('/metrics')['requests']};model=api('/v1/models')['data'][0]['id'];start=time.time();origin=time.monotonic();barrier=threading.Barrier(len(tasks));samples=[]
 print('START',boot['label'],label,'C',thermal.maximum(),flush=True)
 with cf.ThreadPoolExecutor(max_workers=len(tasks)) as pool:
  futures=[pool.submit(generate,t,cap,barrier,model,origin) for t in tasks]
  try:
   while not all(f.done() for f in futures):
    assert thermal.maximum()<63,'Thermal >=63C';assert time.monotonic()-origin<120,'Request wall timeout'
    live=api('/metrics')['live'];assert live['running']<=len(tasks) and live['queued']==0,'Unexpected traffic'
    samples.append(dict(seconds=time.monotonic()-origin,live=live));time.sleep(.2)
   requests=[f.result() for f in futures]
  except BaseException:
   stop.set();subprocess.run(['docker','kill',NAME],capture_output=True);raise
 end=time.time();time.sleep(2.2);native=[r for r in api('/metrics')['requests'] if r['id'] not in ids]
 assert len(native)==len(tasks),'Unexpected native request count'
 pmu=thermal.events(start,end);maximum=max(t for row in thermal.rows if start<=row['unix']<=end for ts in row['temperatures_c'] for t in ts)
 phase=dict(label=label,tasks=tasks,cap=cap,started_unix=start,ended_unix=end,requests=requests,native=native,samples=samples,temperature_max_c=maximum,thermal_pmu=pmu)
 if len(tasks)==2:phase['joint_decode']=q.joint(phase,2)
 assert maximum<63 and not pmu['nonzero_thermal_events'],'Thermal affected measurement'
 boot['cases'].append(phase);save();print('DONE',boot['label'],label,'native',[r.get('decode_tok_s') for r in native],'joint',phase.get('joint_decode'),'C',maximum,flush=True)

def launch(label,enabled,checkres=False):
 cool(52)
 folder=OUT/label;folder.mkdir();(folder/'state').mkdir();(folder/'config').mkdir()
 c=copy.deepcopy(cfg);c['exe']='/experiment/strata';c['log']='/state/engine.log';c['lib_dirs']=['/experiment/lib']+c['lib_dirs'];c['args']+=['--adapt-async','1'];c.setdefault('env',{})['STRATA_SPLIT_ARENA_ASYNC']=str(int(enabled));c['env']['STRATA_ADAPT_NOWAIT']='0';c['env']['STRATA_ADAPT_LAG']='1'
 if checkres:c['env']['STRATA_ADAPT_CHECKRES']='1'
 private=folder/'config/run.json';private.write_text(json.dumps(c));private.chmod(0o600)
 public=copy.deepcopy(c);public['api_key']='[redacted]';q.save(folder/'config-redacted.json',public)
 inspect=json.loads(sh(['docker','inspect','strata-q4']))[0]
 args=['docker','run','-d','--name',NAME,'--restart','no','--cpu-period','100000','--cpu-quota','200000','--init','--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--cpuset-cpus',inspect['HostConfig']['CpusetCpus'],'--memory',str(inspect['HostConfig']['Memory']),'--shm-size','1g','--ulimit','memlock=-1:-1','--tmpfs','/tmp:rw,nosuid,size=1g','--device','nvidia.com/gpu=all','-p','127.0.0.1:8081:8080','-v',str(folder/'config')+':/config:ro','-v',str(folder/'state')+':/state','-v',str(OUT/'artifact')+':/experiment:ro']
 for m in inspect['Mounts']:
  if m['Destination'] not in ['/config','/state']:args+=['-v',m['Source']+':'+m['Destination']+(':ro' if not m['RW'] else '')]
 args += ['--entrypoint','/data/benchmark/.local/share/strata/control-0.1.55/bin/strata',IMAGE,'serve','--profile','/config/run.json']
 sh(args);m=ready(8081);sh(['docker','update','--cpu-quota','-1',NAME]);limits=json.loads(sh(['docker','inspect',NAME]))[0]['HostConfig'];assert limits['NanoCpus']==0 and limits['CpuQuota']==-1,('Startup quota not removed',limits['NanoCpus'],limits['CpuQuota'])
 text=(folder/'state/engine.log').read_text(errors='replace')
 assert ('split arena async: inline pick' in text)==enabled,'Experiment eligibility failed: '+str(re.findall(r'strata experiment:.*|--adapt-async 1 is off.*',text))
 boot=dict(label=label,enabled=enabled,checkres=checkres,engine=m['engine'],cases=[]);result['boots'].append(boot);save()
 print('READY',label,'C',thermal.maximum(),flush=True);return boot

def end_boot(boot):
 sh(['docker','stop','-t','15',NAME]);logs=sh(['docker','logs',NAME]);(OUT/boot['label']/'container.log').write_text(logs.replace(cfg['api_key'],'[redacted]'));sh(['docker','rm',NAME])
 log=(OUT/boot['label']/'state/engine.log').read_text(errors='replace');(OUT/boot['label']/'engine-public.log').write_text(log.replace(cfg['api_key'],'[redacted]'))
 assert 'split arena async: inline pick' in log if boot['enabled'] else 'split arena async: inline pick' not in log
 if boot['checkres']:
  checks=re.findall(r'res check: (\d+) windows, (\d+) with mismatches \((\d+) entries\), (\d+) layer-windows',log)
  assert checks,'No residency verification records';assert all(all(int(v)==0 for v in r[1:]) for r in checks),checks;boot['residency_checks']=checks
 assert not re.search(r'(?i)(cuda error|illegal memory access|device-side assert|out of memory)',log),'GPU error in log'
 save()

try:
 assert not (OUT/'results.json').exists(),'Refuse overwrite'
 before=api('/metrics',8080);assert before['live']['running']==before['live']['queued']==0,'Production busy';q.save(OUT/'production-before.json',dict(engine=before['engine'],live=before['live']))
 result['original_engine_sha256']=sh(['docker','exec','strata-q4','sha256sum',cfg['exe']]).split()[0];result['original_image_id']=json.loads(sh(['docker','inspect','strata-q4']))[0]['Image']
 thermal=q.Thermal('refill-experiment');cool(52);assert api('/metrics',8080)['live']['running']==0,'Production became busy'
 watch=subprocess.Popen(['python3',str(OUT/'watchdog.py')],stdin=subprocess.DEVNULL,stdout=(OUT/'watchdog.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
 sh(['docker','stop','-t','30','strata-q4']);down=True
 b=launch('safety-B',True,True);measure(b,'dual-check',['article','svg'],512);end_boot(b)
 for label,enabled in [('A1',False),('B1',True),('A2',False)]:
  b=launch(label,enabled);measure(b,'warmup',['article','svg'],256)
  for i in range(2):measure(b,'dual-'+str(i+1),['article','svg'],512)
  measure(b,'single',['article'],512);end_boot(b)
 result['completed']=True
except BaseException as e:
 import traceback;result['error']=repr(e);result['traceback']=traceback.format_exc();print('ERROR',result['traceback'],flush=True)
finally:
 for folder in OUT.iterdir():
  engine_log=folder/'state/engine.log'
  if engine_log.is_file():
   (folder/'engine-public.log').write_text(engine_log.read_text(errors='replace').replace(cfg['api_key'],'[redacted]'))
 subprocess.run(['docker','stop','-t','10',NAME],capture_output=True)
 subprocess.run(['docker','rm',NAME],capture_output=True)
 if down:
  cool(55) if thermal else None;subprocess.run(['docker','start','strata-q4'],check=True,capture_output=True);m=ready(8080);q.save(OUT/'production-after.json',dict(engine=m['engine'],live=m['live']));result['production_restored']=True;result['restored_engine_sha256']=sh(['docker','exec','strata-q4','sha256sum',cfg['exe']]).split()[0];assert result['restored_engine_sha256']==result['original_engine_sha256']
 if thermal:thermal.stop()
 result['config_unchanged']=(ROOT/'config/run.json').read_bytes()==original;result['ended_unix']=time.time();save()
 (OUT/'watchdog.disarm').write_text('restored\n')
 if watch:
  try:watch.wait(timeout=5)
  except subprocess.TimeoutExpired:watch.terminate();watch.wait(timeout=5)
 print('FINAL',json.dumps({k:v for k,v in result.items() if k!='boots'}),flush=True)
