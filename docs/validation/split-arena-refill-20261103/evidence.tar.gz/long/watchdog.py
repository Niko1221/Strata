import pathlib,subprocess,time
out=pathlib.Path(__file__).parent;deadline=time.monotonic()+10800
while time.monotonic()<deadline:
 if (out/'watchdog.disarm').exists():raise SystemExit(0)
 time.sleep(2)
print('Watchdog deadline: restoring production',flush=True)
subprocess.run(['docker','kill','strata-refill-long'],capture_output=True)
subprocess.run(['docker','start','strata-q4'],capture_output=True)
for n in ['strata-quant-registers','strata-quant-perf']:subprocess.run(['docker','stop','-t','2',n],capture_output=True)
