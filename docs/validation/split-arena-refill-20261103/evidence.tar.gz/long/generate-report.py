import json,pathlib
p=pathlib.Path(__file__).resolve().parent;s=json.loads((p/'summary.json').read_text());v=json.loads((p/'production-verification.json').read_text())
f=lambda x:f'{x:.2f}'
lines=['# 长上下文跨窗口专家搬运 A/B 实测','','A为原阻塞路径，B为跨窗口异步搬运。两者使用同一实验ELF，NOWAIT=0、LAG=1；原生产默认NOWAIT=1、LAG=2保持未改。每项仅一组A/B样本，每请求生成1536 token。结果是本轮匹配实验调度下的实测差异，不是对原生产默认调度的稳定提速承诺。','', '本轮decode单路提高2.32%–9.49%，双路共同区间总吞吐提高2.76%–7.57%；prefill差异绝对值均不超过0.23%。这是每项仅一组的实测结果，未证明长期稳定收益。','', '## Prefill','', '引擎prefill为本组实际读入token之和除以原生prompt_ms之和。为避免热积累，所有冷输入单独发起max_tokens=1的预填充探针，探针之间降温；双路对应两份输入的探针结果按token/总耗时汇总。客户端prefill为输入总token除以各探针TTFT之和，不含降温间隔。因此本表并非双路同时冷启动的端到端TTFT测试。','', '| 每路输入 | 并发 | A引擎prefill t/s | B引擎prefill t/s | 变化 | A客户端prefill t/s | B客户端prefill t/s |', '|---:|---:|---:|---:|---:|---:|---:|']
for c in s['comparisons']:
 a,b=c['A'],c['B'];lines.append(f"| {c['input_tokens']} | {1 if c['mode']=='single' else 2} | {f(a['prefill_native'])} | {f(b['prefill_native'])} | {c['prefill_native_percent']:+.2f}% | {f(a['prefill_observed'])} | {f(b['prefill_observed'])} |")
lines+=['', '## Decode','', '完成冷输入探针并降温至不高于50°C后，复用同一提示上下文生成1536 token，确认每路至少复用输入长度减64的缓存token。这里测试的是已有长上下文的decode，不是紧跟冷prefill、热积累后的端到端生成。单请求采用原生decode_tok_s。双请求主指标为两路均处于decoding且无prompt读取的共同连续区间内，generated计数增长之和除以区间时长；并非把两路各自全程的native速率相加。','', '| 每路输入 | 并发 | A decode t/s | B decode t/s | 变化 | A各请求native t/s | B各请求native t/s |','|---:|---:|---:|---:|---:|---|---|']
for c in s['comparisons']:
 a,b=c['A'],c['B'];lines.append(f"| {c['input_tokens']} | {1 if c['mode']=='single' else 2} | {f(a['decode_primary'])} | {f(b['decode_primary'])} | {c['decode_percent']:+.2f}% | {', '.join(map(f,a['decode_native_sorted']))} | {', '.join(map(f,b['decode_native_sorted']))} |")
lines+=['', '| 每路输入 | A共同区间各路 t/s（排序） | B共同区间各路 t/s（排序） |','|---:|---|---|']
for c in s['comparisons']:
 if c['mode']=='dual':lines.append(f"| {c['input_tokens']} | {', '.join(map(f,sorted(c['A']['joint']['per_slot_tokens_per_second'].values())))} | {', '.join(map(f,sorted(c['B']['joint']['per_slot_tokens_per_second'].values())))} |")
lines+=['', '双路native值按数值排序，不把排序位置绑定为固定任务或物理GPU。完整SSE时间/内容、每路TTFT、prefill与decode毫秒、MTP接受计数、缓存命中、共同decode区间均在原始记录与summary.json中。双路缓存恢复、极少量未缓存token读取及起止时差仍可能使各自native/SSE速率与共同区间不同。','', '## 窗口耗时与混杂因素','', '| 输入 | 组 | 窗口数 | ms/窗口 | run ms | adapt wait ms |','|---:|---|---:|---:|---:|---:|']
for w in s['windows']:lines.append(f"| {w['case']} | {w['variant']} | {w['windows']} | {f(w['total_ms'])} | {f(w['run_ms'])} | {f(w['adapt_ms'])} |")
lines+=['', '表内为主机侧计时，不能当作CUDA算子的纯设备时间。route_resident=0.1按驻留状态影响选择，CPU/GPU舍入、输出内容、MTP接受率与自适应专家历史均可能变化。本轮各组独立冷启动但组内按相同顺序依次测试，不能完全隔离专家历史与传输重叠的影响。','', '| 输入 | 并发 | A接受/提出MTP草稿 | B接受/提出MTP草稿 | A缓存复用token | B缓存复用token |','|---:|---:|---|---|---|---|']
for c in s['comparisons']:
 vals=[]
 for flag in ['A','B']:
  vals.append(', '.join(f"{x['drafts_accepted']}/{x['drafts_offered']}" for x in c[flag]['native']))
 lines.append(f"| {c['input_tokens']} | {1 if c['mode']=='single' else 2} | {vals[0]} | {vals[1]} | {', '.join(str(x['reused']) for x in c['A']['native'])} | {', '.join(str(x['reused']) for x in c['B']['native'])} |")
lines+=['','双请求原生每请求MTP计数可能不覆盖整个batch；窗口汇总日志中的全batch草稿统计也一并保留。prefill路径没有新增优化；若prefill出现差异，应结合专家状态、重载、缓存与单样本波动解释，不能仅凭差值归因于新增搬运路径。','', '## 验证与恢复','',f"全部请求实际输入准确匹配8000/60000/160000。冷prefill探针输出1 token、复用<=32；decode请求各输出1536并以length结束、复用>=输入长度减64。接受的测试请求最高温度{s['accepted_case_max_c']}°C，IMC thermal事件为0，PMU运行比例>99.9%；包含加载/停机/恢复在内全程最高{s['whole_campaign_max_c']}°C。65°C是主动保护线。",'', '沿用原模型Q6_K_XL、3槽、262144上下文、16工作线程、原层划分、MTP/projection、resident0.1、KV int8、CPU视觉及资源预留。性能请求期间已解除2 CPU启动配额。试验路径需要编译和运行时开关，日志确认B启用、A未启用。详细方法见method.md。','', '实验补丁未部署至生产。原服务8080健康、两张3080均在且各280W、原镜像/配置/引擎哈希匹配，实验与观察容器已退出。','',f"配置SHA256：`{v['original_config_sha256']}`。",'',f"引擎SHA256：`{v['original_engine_sha256']}`。",'', '初次未拆分测试在60000双路时触发65°C主动保护，当时两路仅生成128及502 token、IMC热节流计数仍为0。该失败尝试保存在attempt-uncached，不计入本轮A/B。','', '## 文件','', 'NAS：`<private-NAS-archive>/strata/20261103-q6-refill-long/`。本目录包含固定输入、测试/分析脚本、公开原始记录、补丁、实验二进制和校验清单。完整干净源码与构建日志位于相邻`20261103-q6-batch-refill/`，使用相同二进制与补丁，无新增服务代码修改。私有API密钥与生产配置副本不包含在归档中。']
(p/'report.md').write_text('\n'.join(lines)+'\n')
