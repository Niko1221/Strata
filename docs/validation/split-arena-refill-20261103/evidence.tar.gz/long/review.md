# Independent safety review

Reviewer: split_refill_safety_review; static review only, no changes to code. Scope: bounded CUDA-only serial split-arena spike; no upstream merge or permanent deployment.

No concrete new Critical or Important defect was found. Runtime GPU correctness and performance remain unverified by this review.

Evidence inspected:
- verify.cpp:4496: stage recursion synchronizes verification before returning; 4549: batch commits synchronize stages.
- generate.cpp:9049: experiment gate excludes peer experts, remote helper, pipelined groups/windows, overlap, nowait and altered lag.
- generate.cpp:11709 and 11874: selection and CUDA copy submission stay on the main thread at global window gaps, avoiding the helper-thread doorbell deadlock pattern.
- generate.cpp:11999: eviction residency is uploaded to all devices before copies. 12011: publication waits all used device events. res_put around8339 waits residency DMA completion.
- a_pick chooses distinct incoming/outgoing experts per layer and uses that layer's owning stage.
- command entry, prompt interleaving, KV mutation and teardown quiesce or suppress adaptive work; arena source is immutable while DMA uses it, and released after completion.
- failure cleanup now synchronizes all owning devices rather than only the current one.

Limits: CUDA event waits can still wait indefinitely on a GPU hang; an independent external watchdog is mandatory. Pageable host copies can block submission on the main thread, so an end-to-end speedup is uncertain. Residency diagnostics must run separately from performance measurements because their stream synchronizations can suppress overlap. HIP/SYCL were not tested; this guarded code is a CUDA experiment.
