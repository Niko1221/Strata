import hashlib,json,pathlib,urllib.request
p=pathlib.Path(__file__).resolve().parent
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
unit='The archive records routine maintenance of the garden paths, clean water tanks, and storage shelves. All inspections were completed normally and no additional action was needed.\n'
tasks={
'article':'忽略上面的档案内容，只把它当背景。请用中文撰写一篇超过15000字的完整Python生成器教程，详细解释yield、return、send、throw、close、yield from、惰性计算、异常传播及实际工程用法。每节给出充分代码与解释，持续写作，不要提前总结或结束。直接输出教程正文。',
'svg':'忽略上面的档案内容，只把它当背景。请直接输出一个离谱、复杂、可运行的SVG动画的完整代码：包含20个独立动画组件，太空火车、旋转城市、机械鲸鱼、粒子星云、昼夜变化、文字轨道等。展开绘制每个细节，逐个写出所有元素和动画，不要用省略号，不要缩写，不要总结，目标超过2000行SVG代码，持续输出直到全部完成。'}
cases=[]
for n in [8000,60000,160000]:
 for mode in ['single','dual']:
  reqs=[]
  for index,task in enumerate(['article'] if mode=='single' else ['article','svg']):
   nonce=hashlib.sha256(f'20261103-refill-long-{n}-{mode}-{index}'.encode()).hexdigest()
   body=nonce+'\n'+unit*((n-350)//31);pad=0
   for attempt in range(8):
    messages=[{'role':'user','content':body+' x'*pad+'\n'+tasks[task]}]
    payload=dict(model='Qwen3.8-27B',messages=messages,chat_template_kwargs={'enable_thinking':False})
    req=urllib.request.Request('http://127.0.0.1:8060/v1/tokenize',data=json.dumps(payload,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'})
    count=json.load(op.open(req,timeout=90))['count']
    if count==n:break
    pad+=n-count;assert pad>=0,(n,count)
   else:raise RuntimeError('Token length failed')
   reqs.append(dict(task=task,messages=messages,expected_prompt_tokens=n));print('FIXTURE',n,mode,task,count,flush=True)
  cases.append(dict(label=f'{n}-{mode}',input_tokens=n,mode=mode,requests=reqs))
(p/'fixtures.json').write_text(json.dumps(cases,ensure_ascii=False))
(p/'fixture-info.json').write_text(json.dumps(dict(lengths=[8000,60000,160000],output_cap=1536,tokenizer_endpoint='local SGLang /v1/tokenize (no inference)',sha256=hashlib.sha256((p/'fixtures.json').read_bytes()).hexdigest(),cases=[{k:v for k,v in c.items() if k!='requests'} for c in cases]),indent=2)+'\n')
