"""Read only public status; no API credentials or model contents."""
import subprocess
code='''import pathlib,json,time
p=pathlib.Path.home()/'strata-deploy/comparisons/20261103-q6-refill-long'
print('LOG:', '\\n'.join((p/'controller.log').read_text().splitlines()[-2:]))
print('TEMP:', (p/'refill-long.temperatures.jsonl').read_text().splitlines()[-1])
r=json.loads((p/'results.json').read_text());print('FINISHED:',r.get('completed',False),'ERROR:',r.get('error'),'RESTORED:',r.get('production_restored',False))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','zhangjiayi@<private-server>','python3 -'],input=code,text=True,capture_output=True,check=True);print(r.stdout)
