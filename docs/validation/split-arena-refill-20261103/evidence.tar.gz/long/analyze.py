"""Verify native token accounting, thermal evidence and matched staged A/B measurements."""
import json,pathlib,re,math
p=pathlib.Path(__file__).resolve().parent;raw=p/'raw';r=json.loads((raw/'results.json').read_text())
assert r.get('completed') and not r.get('error'),r.get('error')
assert r.get('production_restored') and r['config_unchanged'] and r['original_engine_sha256']==r['restored_engine_sha256']
assert {b['label'] for b in r['boots']}=={'A','B'}
expected={f'{n}-{mode}' for n in [8000,60000,160000] for mode in ['single','dual']};groups={};windows=[]
for b in r['boots']:
 decodes=[c for c in b['cases'] if c['purpose']=='decode'];assert {c['case'] for c in decodes}==expected
 text=(raw/b['label']/'engine-public.log').read_text()
 assert ('split arena async: inline pick' in text)==b['enabled']
 assert not re.search(r'(?i)(cuda error|illegal memory access|device-side assert|out of memory)',text)
 groups[b['label']]={}
 for c in b['cases']:
  assert c['temperature_max_c']<65 and not c['thermal_pmu']['nonzero_thermal_events'] and c['thermal_pmu']['running_percent_min']>99.9
  assert len(c['requests'])==len(c['native'])==(1 if c['mode']=='single' else 2)
  cap=1 if c['purpose']=='prefill' else 1536
  for req in c['requests']:
   assert req['finish']=='length' and req['usage']['prompt_tokens']==c['input_tokens'] and req['usage']['completion_tokens']==cap
  for req in c['native']:
   assert req['prompt_tokens']==c['input_tokens'] and req['output_tokens']==cap
   assert req['reused']<=32 if cap==1 else req['reused']>=c['input_tokens']-64
   if cap>1:assert all(math.isfinite(req[k]) and req[k]>0 for k in ['decode_ms','decode_tok_s'])
 for c in decodes:
  primes=[x for x in b['cases'] if x['case']==c['case'] and x['purpose']=='prefill'];assert len(primes)==len(c['requests'])
  native=[x for phase in primes for x in phase['native']];observed=[x for phase in primes for x in phase['requests']]
  prefill_native=sum(x['prompt_tokens']-x['reused'] for x in native)*1000/sum(x['prompt_ms'] for x in native)
  prefill_observed=sum(x['usage']['prompt_tokens'] for x in observed)/sum(x['ttft_s'] for x in observed)
  rate=c['native'][0]['decode_tok_s'] if c['mode']=='single' else c['joint_decode']['total_tokens_per_second']
  groups[b['label']][c['case']]=dict(input_tokens=c['input_tokens'],mode=c['mode'],prefill_native=prefill_native,prefill_observed=prefill_observed,prefill_native_records=native,decode_primary=rate,decode_native_sorted=sorted(x['decode_tok_s'] for x in c['native']),decode_sse=[x['decode_sse_tok_s'] for x in c['requests']],ttft_s=[x['ttft_s'] for x in c['requests']],temperature_max_c=max(x['temperature_max_c'] for x in [c]+primes),native=c['native'],joint=c.get('joint_decode'))
 batch=[]
 for line in text.splitlines():
  if 'strata batch:' in line and 'windows, avg' in line:
   m=re.search(r'(\d+) windows, avg ([\d.]+) rows, ([\d.]+) ms/window = run ([\d.]+) .*? \+ commit ([\d.]+) \+ emit ([\d.]+) \+ adapt wait ([\d.]+);',line);assert m,line
   n,rows,total,run,commit,emit,adapt=map(float,m.groups());batch.append(dict(windows=int(n),rows=rows,total_ms=total,run_ms=run,commit_ms=commit,emit_ms=emit,adapt_ms=adapt,line=line))
 dual=[c for c in decodes if c['mode']=='dual'];assert len(batch)==len(dual),(len(batch),len(dual))
 for c,stat in zip(dual,batch):stat['variant']=b['label'];stat['case']=c['case'];windows.append(stat)
comparisons=[]
for n in [8000,60000,160000]:
 for mode in ['single','dual']:
  label=f'{n}-{mode}';a,b=(groups[g][label] for g in ['A','B']);comparisons.append(dict(case=label,input_tokens=n,mode=mode,A=a,B=b,prefill_native_percent=100*(b['prefill_native']/a['prefill_native']-1),prefill_observed_percent=100*(b['prefill_observed']/a['prefill_observed']-1),decode_percent=100*(b['decode_primary']/a['decode_primary']-1)))
temps=[json.loads(x) for x in (raw/'refill-long.temperatures.jsonl').read_text().splitlines() if x.strip()]
s=dict(method='Independent cold-prefill probes, cooldown, cached-context decode; each decode request 1536 tokens',comparisons=comparisons,windows=windows,accepted_case_max_c=max(c['temperature_max_c'] for b in r['boots'] for c in b['cases']),whole_campaign_max_c=max(t for row in temps for pair in row['temperatures_c'] for t in pair),all_accepted_thermal_events_zero=True,config_unchanged=True,original_engine_restored=True)
(p/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
for c in comparisons:print(c['case'],'prefill',round(c['A']['prefill_native'],2),round(c['B']['prefill_native'],2),f"{c['prefill_native_percent']:+.2f}%",'decode',round(c['A']['decode_primary'],2),round(c['B']['decode_primary'],2),f"{c['decode_percent']:+.2f}%")
print('max temperatures:',s['accepted_case_max_c'],s['whole_campaign_max_c'])
