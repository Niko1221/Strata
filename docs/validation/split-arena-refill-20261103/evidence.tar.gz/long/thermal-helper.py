#!/usr/bin/env python3
"""Thermally gated, identical-fixture Strata quantization measurements."""
import argparse
import concurrent.futures
import json
import pathlib
import re
import subprocess
import threading
import time
import urllib.request

ROOT = pathlib.Path.home() / 'strata-deploy'
OUT = ROOT / 'comparisons/20261030-q4-q6'
IMAGE = 'strata:control-0.1.54-engine-0.1.54-cuda13'
TASK = '请用中文详细讲解Python生成器的工作方式、yield与return的区别、惰性计算的好处及常见使用场景，并给出大量示例、深入解释及完整教程。请连续写作至少10000字，不要提前结束。'
UNIT = 'The archive records routine maintenance of the garden paths, clean water tanks, and storage shelves. All inspections were completed normally and no additional action was needed.\n'


def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    tmp.replace(path)


def fixtures(path):
    # Local sglang uses the same tokenizer; serving usage is verified again.
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def item(target, label):
        body = f'[quantization comparison 20261030 {label}]\n'+UNIT*((target-300)//31)
        padding = 0
        for _ in range(8):
            messages = [{'role':'user', 'content':body+' x'*padding+'\n'+TASK}]
            req = urllib.request.Request('http://127.0.0.1:8060/v1/tokenize',
                data=json.dumps({'model':'Qwen3.8-27B','messages':messages,
                                 'chat_template_kwargs':{'enable_thinking':False}}).encode(),
                headers={'Content-Type':'application/json'})
            count = json.load(op.open(req, timeout=30))['count']
            if count == target:
                return {'messages':messages}
            padding += target-count
            assert padding >= 0
        raise RuntimeError('Tokenizer target did not converge')
    data = {'prefill': [{'target':n,'round':i,'item':item(n,f'prefill-{n}-{i}')} for n in [4096,16384] for i in range(3)],
            'decode':[item(16384,f'decode-slot-{i}') for i in range(4)]}
    save(path,data)


class Thermal:
    def __init__(self, tag):
        self.tag, self.rows, self.last = tag, [], None
        self.names = ['strata-quant-registers','strata-quant-perf']
        suffix='' if not (OUT/(tag+'.temperatures.jsonl')).exists() else '.'+str(int(time.time()))
        self.temp_log = OUT/(tag+suffix+'.temperatures.jsonl')
        self.perf_log = OUT/(tag+suffix+'.perf.stat')
        code = '''import os,time,json
fds=[os.open('/sys/bus/pci/devices/'+b+'/config',os.O_RDONLY) for b in ['0000:ff:14.0','0000:ff:14.1','0000:ff:17.0','0000:ff:17.1']]
def read(fd,a):
 d=os.pread(fd,4,a)
 assert len(d)==4
 return int.from_bytes(d,'little')
for fd in fds: assert read(fd,0x108)&(1<<29)
while True:
 print(json.dumps({'unix':time.time(),'temperatures_c':[[read(fd,0x150)&255,read(fd,0x154)&255] for fd in fds]}),flush=True)
 time.sleep(.5)
'''
        common=['docker','run','--rm','--network','none','--read-only','--mount','type=bind,src=/,dst=/host,readonly','--user','0:0']
        tail=['--entrypoint','/usr/sbin/chroot',IMAGE,'/host','/usr/bin/taskset','-c','16,38']
        self.err = (OUT/(tag+'.observer-errors.log')).open('w')
        self.reg = subprocess.Popen(common+['--name',self.names[0],'--cap-add','SYS_ADMIN']+tail+['/usr/bin/python3','-c',code],stdout=subprocess.PIPE,stderr=self.err,text=True,bufsize=1)
        self.thread = threading.Thread(target=self.consume,daemon=True)
        self.thread.start()
        events=','.join(f'uncore_imc_{ch}/{event}/' for ch in [0,1,4,5] for event in ['clockticks','event=0x86,umask=0','event=0x41,umask=0xff'])
        self.pf = self.perf_log.open('w')
        self.perf_start = time.time()
        self.perf = subprocess.Popen(common+['--name',self.names[1],'--cap-add','PERFMON','--cap-add','SYS_PTRACE','--security-opt','seccomp=unconfined','--pid','host']+tail+['/usr/bin/perf','stat','-a','-I','1000','-x',',','-e',events,'--','/bin/sleep','14400'],stdout=self.pf,stderr=subprocess.STDOUT)
        for _ in range(40):
            if self.last:break
            time.sleep(.25)
        assert self.last, 'Temperature observer failed'

    def consume(self):
        with self.temp_log.open('w') as f:
            for line in self.reg.stdout:
                r=json.loads(line);self.rows.append(r);self.last=r
                f.write(line);f.flush()

    def maximum(self):
        assert self.last and time.time()-self.last['unix']<3, 'Stale temperature measurement'
        return max(t for ts in self.last['temperatures_c'] for t in ts)

    def cool(self):
        since=time.monotonic();last_print=-100
        while self.maximum()>52:
            if time.monotonic()-last_print>25:
                print('COOLING max DIMM',self.maximum(),'C',flush=True);last_print=time.monotonic()
            assert time.monotonic()-since<900, 'Cooling timeout'
            time.sleep(2)
        return self.last

    def events(self,start,end):
        selected=[]
        pattern=r'^([0-9.]+),([0-9.]+),[^,]*,uncore_imc_(\d+)/(.*?)/,([0-9.]+),([0-9.]+)'
        for line in self.perf_log.read_text().splitlines():
            m=re.search(pattern,line)
            if not m:continue
            t,v,ch,ev,run,fraction=m.groups();stamp=self.perf_start+float(t)
            if start-2 <= stamp <= end+2:
                selected.append({'unix':stamp,'channel':int(ch),'event':ev,'value':float(v),'running_pct':float(fraction)})
        assert selected and min(x['running_pct'] for x in selected)>99.9,'Missing/multiplexed PMU data'
        nonzero=[x for x in selected if x['event'].startswith('event=') and x['value']>0]
        return {'samples':len(selected),'nonzero_thermal_events':nonzero,'running_percent_min':min(x['running_pct'] for x in selected)}

    def stop(self):
        for name in self.names:
            subprocess.run(['docker','stop','--signal','SIGINT','-t','2',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.reg.wait(timeout=10);self.perf.wait(timeout=10)
        self.pf.close();self.err.close()


def joint(phase,count):
    runs=[];current=[];ids=None
    for s in phase['samples']:
        live=s['live'];active=[z for z in live['slots'] if z.get('state')=='decoding']
        if count==1 and live.get('outside_slots')==1 and live.get('phase')=='answering' and isinstance(live.get('generated'),int):
            active=[{'slot':'single','state':'decoding','generated':live['generated']}]
        valid=len(active)==count and live['running']==count and not any(z.get('state')=='reading' for z in live['slots'])
        newids=tuple(sorted(z['slot'] for z in active)) if valid else None
        if valid and (ids is None or ids==newids):current.append(s);ids=newids
        else:
            if current:runs.append(current)
            current=[s] if valid else [];ids=newids
    if current:runs.append(current)
    assert runs,'No joint decode window'
    r=max(runs,key=lambda r:r[-1]['seconds']-r[0]['seconds'])
    assert len(r)>=8,'Insufficient joint decode samples'
    lo,hi=r[1],r[-2];elapsed=hi['seconds']-lo['seconds']
    def counts(live):
        if count==1 and live.get('outside_slots')==1:
            return {'single':live['generated']}
        return {z['slot']:z['generated'] for z in live['slots'] if z.get('state')=='decoding'}
    a,b=counts(lo['live']),counts(hi['live'])
    assert a.keys()==b.keys()
    rates={str(k):(b[k]-a[k])/elapsed for k in a}
    return {'seconds':elapsed,'per_slot_tokens_per_second':rates,'total_tokens_per_second':sum(rates.values())}


def main():
    p=argparse.ArgumentParser();p.add_argument('--tag');p.add_argument('--fixtures',type=pathlib.Path,required=True)
    p.add_argument('--make-fixtures',action='store_true');p.add_argument('--prefill-only',action='store_true')
    p.add_argument('--output-tokens',type=int,default=768);p.add_argument('--resume',action='store_true')
    args=p.parse_args()
    if args.make_fixtures:fixtures(args.fixtures);return
    cfg=json.loads((ROOT/'config/run.json').read_text())
    headers={'Content-Type':'application/json','Authorization':'Bearer '+cfg['api_key']}
    op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def api(path,payload=None):
        data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode()
        return json.load(op.open(urllib.request.Request('http://127.0.0.1:8080'+path,data=data,headers=headers),timeout=30))
    model=api('/v1/models')['data'][0]['id']
    before=api('/metrics');assert before['live']['running']==before['live']['queued']==0
    fixture=json.loads(args.fixtures.read_text())
    result={'tag':args.tag,'model':model,'started_unix':time.time(),'metadata_before':before,'phases':[],
        'method':'Uncached prefill max_tokens=1; cached 16K decode 768 tokens; temperature=0 thinking disabled; DIMM <=52C before each operation, interrupt at65C; PMU thermal events must be zero. Original four serving slots retained.'}
    dest=OUT/(args.tag+'.json')
    if args.resume:
        result=json.loads(dest.read_text());assert 'ended_unix' not in result
    else:
        assert not dest.exists(),'Existing results; use --resume or a new tag'
    thermal=Thermal(args.tag)
    result.setdefault('observer_runs',[]).append({'temperature_file':thermal.temp_log.name,'perf_file':thermal.perf_log.name,'perf_started_unix':thermal.perf_start})
    def generate(item,cap,origin,barrier):
        barrier.wait();started=time.monotonic();events=[];usage={};timings={};finish=None
        payload=dict(item,model=model,max_tokens=cap,temperature=0,stream=True,stream_options={'include_usage':True},chat_template_kwargs={'enable_thinking':False})
        req=urllib.request.Request('http://127.0.0.1:8080/v1/chat/completions',data=json.dumps(payload,ensure_ascii=False).encode(),headers=headers)
        with op.open(req,timeout=600) as response:
            for line in response:
                if thermal.maximum()>=65:raise RuntimeError('THERMAL GUARD: >=65C')
                if not line.startswith(b'data: '):continue
                raw=line[6:].strip()
                if raw==b'[DONE]':break
                e=json.loads(raw);now=time.monotonic()
                if e.get('error'):raise RuntimeError(e['error'])
                if e.get('usage'):usage=e['usage']
                if e.get('timings'):timings=e['timings']
                for choice in e.get('choices',[]):
                    text=choice.get('delta',{}).get('content') or choice.get('delta',{}).get('reasoning_content')
                    if text:events.append({'seconds':now-origin,'content':text})
                    if choice.get('finish_reason'):finish=choice['finish_reason']
        first,last=events[0]['seconds'],events[-1]['seconds']
        assert usage['completion_tokens']==cap and finish=='length',(usage,finish)
        return {'usage':usage,'timings':timings,'finish_reason':finish,'ttft_seconds':first-(started-origin),
            'decode_tokens_per_second':(cap-1)/(last-first) if last>first else None,'events':events,
            'first_content_seconds':first,'last_content_seconds':last}

    cache_retries={}
    def operation(kind,items,cap,round_id,target):
        if any(p['kind']==kind and p['concurrency']==len(items) and p['round']==round_id and p['target_prompt_tokens']==target for p in result['phases']):return
        thermal.cool()
        assert api('/metrics')['live']['running']==0
        start=time.time();origin=time.monotonic();barrier=threading.Barrier(len(items))
        phase={'kind':kind,'concurrency':len(items),'round':round_id,'target_prompt_tokens':target,
               'started_unix':start,'samples':[],'temperature_before':thermal.last}
        print('START',args.tag,kind,'n',len(items),'round',round_id,'maxC',thermal.maximum(),flush=True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(items)) as pool:
            futures=[pool.submit(generate,item,cap,origin,barrier) for item in items]
            while not all(f.done() for f in futures):
                phase['samples'].append({'seconds':time.monotonic()-origin,'live':api('/metrics')['live']})
                time.sleep(.25)
            phase['requests']=[f.result() for f in futures]
        phase['wall_seconds']=time.monotonic()-origin;phase['ended_unix']=time.time()
        for r in phase['requests']:assert r['usage']['prompt_tokens']==target,r['usage']
        phase['temperature_after']=thermal.last
        phase['max_temperature_c']=max(t for row in thermal.rows if start<=row['unix']<=phase['ended_unix'] for ts in row['temperatures_c'] for t in ts)
        time.sleep(2.2)
        phase['thermal_pmu']=thermal.events(start,phase['ended_unix'])
        phase['accepted']=not phase['thermal_pmu']['nonzero_thermal_events'] and phase['max_temperature_c']<65
        if kind=='decode':
            try:phase['joint_decode']=joint(phase,len(items))
            except BaseException:
                save(OUT/(args.tag+'.failed-phase.'+str(int(time.time()))+'.json'),phase)
                raise
        if kind=='prefill':
            for r in phase['requests']:
                assert r['usage'].get('prompt_tokens_details',{}).get('cached_tokens',0)<100,r['usage']
                assert r['timings']['prompt_n']>target-100,r['timings']
        if kind=='decode':
            if any(r['usage'].get('prompt_tokens_details',{}).get('cached_tokens',0)<=target-32 for r in phase['requests']):
                save(OUT/(args.tag+'.cache-warmup.'+str(int(time.time()))+'.json'),phase)
                assert phase['accepted'],'Thermally affected warmup; stop for investigation'
                key=(len(items),round_id)
                cache_retries[key]=cache_retries.get(key,0)+1
                assert cache_retries[key]<=2,'Repeated cache misses; stop for investigation'
                print('WARMUP ONLY: incomplete prefix cache; cool and repeat same decode case',flush=True)
                return operation(kind,items,cap,round_id,target)
        result['phases'].append(phase);save(dest,result)
        print('DONE',args.tag,kind,'maxC',phase['max_temperature_c'],'accepted',phase['accepted'],
              'prefill',[r['timings'].get('prompt_per_second') for r in phase['requests']],
              'decode',phase.get('joint_decode'),flush=True)
        assert phase['accepted'],'Thermally affected sample discarded; rerun required'

    try:
        # The first prefill operation also warms the engine; use three separate fixtures.
        for f in fixture['prefill']:
            operation('prefill',[f['item']],1,f['round'],f['target'])
        if not args.prefill_only:
            # Prime every 16K prompt separately, cooling between them. This is not a timed prefill sample.
            for i,item in enumerate(fixture['decode']):operation('prime',[item],1,i,16384)
            for count in [1,2,4]:
                for round_id in range(3):operation('decode',fixture['decode'][:count],args.output_tokens,round_id,16384)
        result['metadata_after']=api('/metrics');result['ended_unix']=time.time()
        assert result['metadata_after']['live']['running']==result['metadata_after']['live']['queued']==0
        save(dest,result);print('COMPLETE',args.tag,flush=True)
    finally:thermal.stop()


if __name__=='__main__':main()
