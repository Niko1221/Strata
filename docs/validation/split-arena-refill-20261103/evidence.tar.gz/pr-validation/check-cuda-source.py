"""Verify submitted CUDA translation unit against the measured source; compile it."""
import hashlib
import json
import pathlib
import shlex
import subprocess

root = pathlib.Path(__file__).resolve().parent
measured = root.parent / '20261103-q6-batch-refill'
entry = next(x for x in json.loads((measured / 'build-debian/compile_commands.json').read_text())
             if x['file'].endswith('/src/program/generate.cpp'))
args = shlex.split(entry['command'])
source = args[-1]
flags = []
i = 0
while i < len(args):
    if args[i] == '-o':
        i += 2
    elif args[i] == '-c' or args[i] == source:
        i += 1
    else:
        flags.append(args[i])
        i += 1
submitted = root / 'repo/src/program/generate.cpp'

def preprocess(path, enabled):
    command = flags if enabled else [x for x in flags if 'STRATA_SPLIT_ARENA_ASYNC_EXPERIMENT' not in x]
    out = subprocess.check_output(command + ['-E', '-P', str(path)], cwd=entry['directory'])
    return hashlib.sha256(out).hexdigest()

checks = {
    'measured_cuda_enabled': preprocess(source, True),
    'submitted_cuda_enabled': preprocess(submitted, True),
    'baseline_macro_disabled': preprocess(measured / 'generate.original.cpp', False),
    'submitted_macro_disabled': preprocess(submitted, False),
}
assert checks['measured_cuda_enabled'] == checks['submitted_cuda_enabled'], checks
assert checks['baseline_macro_disabled'] == checks['submitted_macro_disabled'], checks
lines = submitted.read_text().splitlines()
guard_start = next(i for i, line in enumerate(lines) if line.startswith('#if defined(STRATA_SPLIT_ARENA_ASYNC_EXPERIMENT)'))
guard = '\n'.join(lines[guard_start:guard_start + 2])
assert submitted.read_text().count(guard) == 9
for backend in ('STRATA_USE_HIP', 'STRATA_HIP_GFX906', 'STRATA_GPU_METAL'):
    probe = guard + '\nexperiment_enabled\n#endif\n'
    out = subprocess.check_output(['/usr/bin/c++', '-E', '-P', '-x', 'c++',
        '-DSTRATA_SPLIT_ARENA_ASYNC_EXPERIMENT=1', '-D' + backend + '=1', '-'], input=probe.encode())
    assert not out.strip(), (backend, out)
checks['backend_exclusion_preprocessor_checks'] = '3 passed; not backend builds'
compile_command = flags + ['-c', str(submitted), '-o', str(root / 'submitted-generate.o')]
subprocess.run(compile_command, cwd=entry['directory'], check=True)
checks['submitted_cuda_host_translation_unit_compiled'] = True
(root / 'source-verification.json').write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps(checks, indent=2))
